Contains assets from ambientCG.com, licensed under CC0 1.0 Universal.
